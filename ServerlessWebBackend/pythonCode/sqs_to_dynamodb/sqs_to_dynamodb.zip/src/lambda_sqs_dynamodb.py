import boto3, json
import random
import string
import os

# global CLIENT, TABLE_NAME
CLIENT = boto3.client("dynamodb")
TABLE_NAME = os.environ.get("TABLE_NAME", "ServerlessWebBackend-Table")  # Default to "OrdersTable" if not set


def generate_id(length=12):
    chars = string.ascii_letters + string.digits
    return ''.join(random.choices(chars, k=length))


def _extract_orders(event):
    records = event.get("Records") if isinstance(event, dict) else None
    if not records:
        return [event]

    orders = []
    for record in records:
        body = record.get("body", "{}")
        if isinstance(body, str):
            orders.append(json.loads(body))
        elif isinstance(body, dict):
            orders.append(body)
        else:
            orders.append({})
    return orders


def put_item(event, context):
    """Put an order in DynamoDB table"""
    print("Received event: " + json.dumps(event, indent=2))
    orders = _extract_orders(event)
    for order in orders:
        print("Putting item in DynamoDB: " + json.dumps(order, indent=2))
        order_id = order.get("id") or order.get("orderId") or generate_id()
        customer_name = order.get("customerName") or order.get("customer") or "Unknown Customer"
        product = order.get("product", "Unknown Product")
        quantity = order.get("quantity", 0)
        if (order_id and customer_name and product and quantity): 
            CLIENT.put_item(
                TableName=TABLE_NAME,
                Item={
                    "id": {"S": order_id},
                    "customerName": {"S": customer_name},
                    "product": {"S": product},
                    "quantity": {"N": str(quantity)},
                },
            )
        else:
            CLIENT.put_item(
                TableName=TABLE_NAME,
                Item=json.dumps(order, indent=2)
            ) 
    